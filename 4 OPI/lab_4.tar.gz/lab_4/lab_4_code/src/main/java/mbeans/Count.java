package mbeans;

import javax.management.Notification;
import javax.management.NotificationBroadcasterSupport;
import java.io.Serializable;
import java.util.List;

import bd.PointsBDManager;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import point.Point;

@Named
@ApplicationScoped
public class Count extends NotificationBroadcasterSupport implements CountMBean, Serializable {

    private final PointsBDManager pointsBDManager = new PointsBDManager();
    private long sequenceNumber = 0;

    @Override
    public long getNumberOfAllPoints() {
        List<Point> points = pointsBDManager.getAllPoints();
        long count = points.size();
        if (count % 5 == 0 && count != 0) {
            sendNotification(new Notification("Points multiple of 5", this.getClass().getName(), sequenceNumber++, "Total points: " + count));
        }
        return count;
    }

    @Override
    public long getNumberOfFailedPoints() {
        return pointsBDManager.getFailedPoints().size();
    }
}