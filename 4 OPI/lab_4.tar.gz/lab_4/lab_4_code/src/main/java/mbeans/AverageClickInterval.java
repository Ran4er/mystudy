package mbeans;

import javax.management.NotificationBroadcaster;
import javax.management.NotificationBroadcasterSupport;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.Queue;

@Named
@ApplicationScoped
public class AverageClickInterval extends NotificationBroadcasterSupport implements AverageClickIntervalMBean, Serializable {
    private Queue<Long> clickTimes = new LinkedList<>();
    private static final int MAX_RECORDS = 10;

    @Override
    public double getAverageInterval() {
        if (clickTimes.size() < 2) return 0.0;
        Long[] times = clickTimes.toArray(new Long[0]);
        long total = 0;
        for (int i = 1; i < times.length; i++) {
            total += (times[i] - times[i-1]);
        }
        return total / (double)(times.length - 1);
    }

    @Override
    public void recordClick() {
        clickTimes.add(System.currentTimeMillis());
        if (clickTimes.size() > MAX_RECORDS) {
            clickTimes.poll();
        }
    }
}